﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GoryachevaValeria
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public object ValidationText { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Email_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            
        }

        private void Name_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Za-яА-Я\\s]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void Patronyc_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Za-яА-Я\\s]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void checkButton_Click(object sender, RoutedEventArgs e)
        {
            if (Name.Text.Length < 3 || Name.Text.Length > 25)
            {
                MessageBox.Show("Некорректное имя!");
                Name.Focus();
            }
            else
            {
                MessageBox.Show("Имя: " + Name.Text);
            }
        }

        private void checkButton1_Click(object sender, RoutedEventArgs e)
        {
            if (Patronyc.Text.Length < 2 || Patronyc.Text.Length > 30)
            {
                MessageBox.Show("Некорректная фамилия!");
                Patronyc.Focus();
            }
            else
            {
                MessageBox.Show("Фамилия: " + Patronyc.Text);
            }
        }

        private void checkButton2_Click(object sender, RoutedEventArgs e)
        {
            string email = Email.Text;
            if (Regex.IsMatch(email,"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+[A-Za-z]{2,}$"))
            {
                MessageBox.Show ( "Правильный email");
                Email.Focus();
            }
            else
            {
                MessageBox.Show("Не правильный email");
                Email.Focus();
            }
        }
    }
    }

